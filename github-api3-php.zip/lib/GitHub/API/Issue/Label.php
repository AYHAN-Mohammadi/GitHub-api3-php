<?php

namespace GitHub\API\Issue;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Label extends Api {}
