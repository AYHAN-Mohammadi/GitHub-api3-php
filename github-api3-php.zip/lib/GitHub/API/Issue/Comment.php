<?php

namespace GitHub\API\Issue;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Comment extends Api
{
    const MIME_TYPE_RESOURCE = 'issuecomment';
    public function all($username, $repo, $issueId = null, $format = self::FORMAT_RAW)
    {
        $url = "repos/$username/$repo/issues/$issueId/comments";
    
        return $this->processResponse(
            $this->requestGet($url, array(), $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array()))
        );
    }
  
    public function get($username, $repo, $id, $format = self::FORMAT_RAW)
    {
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/issues/comments/$id", array(), $options)
        );
    }
 
    public function create($username, $repo, $issueId, $body, $format = self::FORMAT_RAW)
    {
        $details = array('body' => $body);
        
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestPost("repos/$username/$repo/issues/$issueId/comments", $details, $options)
        );
    }
    public function update($username, $repo, $id, $body, $format = self::FORMAT_RAW)
    {
        $details = array('body' => $body);
        
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestPatch("repos/$username/$repo/issues/comments/$id", $details, $options)
        );
    }
    public function delete($username, $repo, $id)
    {
        return $this->processResponse(
            $this->requestDelete("repos/$username/$repo/issues/comments/$id")
        );
    }
}
