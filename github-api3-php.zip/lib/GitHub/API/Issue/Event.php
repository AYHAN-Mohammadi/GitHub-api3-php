<?php

namespace GitHub\API\Issue;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Event extends \GitHub\API\Event\Event
{
    public function all($usename, $repo, $issueId)
    {
        return $this->_all("repos/$username/$repo/issues/$issueId/events");
    }
}
