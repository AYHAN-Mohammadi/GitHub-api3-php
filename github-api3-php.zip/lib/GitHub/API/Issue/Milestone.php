<?php

namespace GitHub\API\issue;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Milestone extends Api
{
    const STATE_OPEN        = 'open';
    const STATE_CLOSED      = 'closed';
    const SORT_CREATED      = 'due_date';
    const SORT_UPDATED      = 'completeness';
    const SORT_DIR_ASC      = 'asc';
    const SORT_DIR_DESC     = 'desc';
    public function all($username, $repo, $filters = array(), $sort = array(), $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        $url = "repos/$username/$repo/milestones";
        $params   = array_merge($filters, $sort, $this->buildPageParams($page, $pageSize));
    
        return $this->processResponse(
            $this->requestGet($url, $params)
        );
    }
  
    public function get($username, $repo, $id)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/milestones/$id")
        );
    }
  
    public function create($username, $repo, $title, $state = self::STATE_OPEN, $description = null, $dueOn = null)
    {
        $details = array_merge(
            array('body' => $body),
            $this->buildParams(array(
                'state'       => $state,
                'description' => $description,
                'due_on'      => $dueOn
            ))
        );
    
        return $this->processResponse(
            $this->requestPost("repos/$username/$repo/milestones", $details)
        );
    }
    public function update($username, $repo, $id, $title, $state = self::STATE_OPEN, $description = null, $dueOn = null)
    {
        $details = array_merge(
            array('body' => $body),
            $this->buildParams(array(
                'state'       => $state,
                'description' => $description,
                'due_on'      => $dueOn
            ))
        );
        return $this->processResponse(
            $this->requestPatch("repos/$username/$repo/milestones/$id", $details)
        );
    }
    public function delete($username, $repo, $id)
    {
        return $this->processResponse(
            $this->requestDelete("repos/$username/$repo/milestones/$id")
        );
    }

}
