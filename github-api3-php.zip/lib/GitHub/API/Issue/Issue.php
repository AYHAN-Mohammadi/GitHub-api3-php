<?php

namespace GitHub\API\Issue;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
abstract class Issue extends Api
{
    const MIME_TYPE_RESOURCE = 'issue';
    const FILTER_ASSIGNED   = 'assigned';
    const FILTER_CREATED    = 'created';
    const FILTER_MENTIONED  = 'mentioned';
    const FILTER_SUBSCRIBED = 'subscribed';
    const STATE_OPEN        = 'open';
    const STATE_CLOSED      = 'closed';
    const SORT_CREATED      = 'created';
    const SORT_UPDATED      = 'updated';
    const SORT_COMMENTS     = 'comments';
    const SORT_DIR_ASC      = 'asc';
    const SORT_DIR_DESC     = 'desc';
    protected $comment   = null;
    protected $event   = null;
    protected $label   = null;
    protected $milestone   = null;
    public function comments()
    {
        if (null === $this->comment)
            $this->comment = new Comment($this->getTransport());

        return $this->comment;
    }
    public function events()
    {
        if (null === $this->event)
            $this->event = new Event($this->getTransport());

        return $this->event;
    }

    public function labels()
    {
        if (null === $this->label)
            $this->label = new Label($this->getTransport());

        return $this->label;
    }

    public function milestones()
    {
        if (null === $this->milestone)
            $this->milestone = new Milestone($this->getTransport());

        return $this->milestone;
    }
}
