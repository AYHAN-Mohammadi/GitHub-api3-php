<?php

namespace GitHub\API\Gist;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Comment extends Api {
    const MIME_TYPE_RESOURCE = 'gistcomment';
    public function all($gistId, $format = self::FORMAT_RAW)
    {
        $url = "gists/$gistId/comments";
        return $this->processResponse(
            $this->requestGet($url, array(), $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array()))
        );
    }

    public function get($id, $format = self::FORMAT_RAW)
    {
        return $this->processResponse(
            $this->requestGet("gists/comments/$id", array(), $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array()))
        );
    }

    public function create($gistId, $body, $format = self::FORMAT_RAW)
    {
        $details = array('body' => $body);

        return $this->processResponse(
            $this->requestPost("gists/$gistId/comments", $details, $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array()))
        );
    }

    public function update($id, $body, $format = self::FORMAT_RAW)
    {
        $details = array('body' => $body);
        return $this->processResponse(
            $this->requestPatch("gists/comments/$id", $details, $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array()))
        );
    }
    public function delete($id)
    {
        return $this->processResponse($this->requestDelete("gists/comments/$id"));
    }
}
