<?php

namespace GitHub\API\Gist;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Gist extends Api
{
    const GIST_TYPE_PRIVATE     = 'private';
    const GIST_TYPE_PUBLIC      = 'public';
    const GIST_TYPE_STARRED     = 'starred';
    protected $comment  = null;
    public function all($username = null, $gistType = self::GIST_TYPE_PUBLIC, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        if (is_null($username))
        {
            if (false === $this->isAuthenticated())
                $url = 'gists';   
            else
            {
                if (self::GIST_TYPE_STARRED === $gistType)
                    $url = 'gists/starred';
                else
                    $url = "gists";
            }
        }
        else
        {
            if (self::GIST_TYPE_PUBLIC !== $gistType)
                throw new ApiException("Unsupported [$gistType] gistType option. Unathenticated user requests can only list public gists [ApiGist::GIST_TYPE_PUBLIC]");

            $url ="users/$username/gists";
        }

        return $this->processResponse(
            $this->requestGet($url, $this->buildPageParams($page, $pageSize))
        );
    }
    public function get($id)
    {
        return $this->processResponse($this->requestGet("gists/$id"));
    }

    public function create($files, $public, $description = '')
    {
        $details = array(
          'description' => $description,
          'public'      => $public,
          'files'       => $files
        );

        return $this->processResponse($this->requestPost('gists', $details));
    }

    public function update($id, $files = array(), $description = '')
    {
        $details = array(
          'description' => $description,
          'files'       => $files
        );

        return $this->processResponse(
            $this->requestPatch("gists/$id", $this->buildParams($details))
        );
    }

    public function star($id)
    {
        return $this->processResponse($this->requestPut("gists/$id/star"));
    }

    public function unstar($id)
    {
        return $this->processResponse($this->requestDelete("gists/$id/star"));
    }

    public function isStarred($id)
    {
        return $this->processResponse($this->requestGet("gists/$id/star"));
    }

    public function fork($id)
    {
        return $this->processResponse($this->requestPost("gists/$id/fork"));
    }

    public function delete($id)
    {
        return $this->processResponse($this->requestDelete("gists/$id"));
    }

    public function comments()
    {
        if (null === $this->comment)
            $this->comment = new Comment($this->getTransport());

        return $this->comment;
    }
}
