<?php

namespace GitHub\API\Org;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Repo extends \GitHub\API\Repo\Repo
{
    protected $allowedRepoTypes = array(
        self::REPO_TYPE_ALL, self::REPO_TYPE_PUBLIC, self::REPO_TYPE_PRIVATE
    );
    public function all($organization, $repoType = self::REPO_TYPE_ALL, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        if (false === in_array($repoType, $this->allowedRepoTypes))
          throw new Exception("Unsupported $repoType option. Available types are " . join(", ", $this->allowedRepoTypes));
    
        if (false === $this->isAuthenticated() && self::REPO_TYPE_PUBLIC !== $repoType)
          throw new Exception("Unsupported $repoType option. Unathenticated user requests can only list public organization repositories [ApiRepo::REPO_TYPE_PUBLIC]");
    
        return $this->processResponse(
            $this->requestGet("orgs/$organization/repos", $params)
        );
    }
  
    public function create($organization, $repo, $details = array())
    {
        return $this->_create("orgs/$organization/repos", $repo, $details);
    }
}
