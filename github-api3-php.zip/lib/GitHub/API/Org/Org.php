<?php

namespace GitHub\API\Org;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Org extends Api
{
    protected $repo  = null;
    public function repos()
    {
        if (null === $this->repo)
          $this->repo = new Repo($this->getTransport());
    
        return $this->repo;
    }
}
