<?php

namespace GitHub\API\Authentication;
class Basic implements AuthenticationInterface
{
    private $username;
    private $password;
    public function __construct($username, $password)
    {
        $this->username = $username;
        $this->password = $password;
    }
    
    public function getUsername()
    {
        return $this->username;
    }
    
    public function getPassword()
    {
        return $this->password;
    }
    
    public function setUsername($username)
    {
        $this->username = $username;
    }
    
    public function setPassword($password)
    {
        $this->password = $password;
    }
    public function authenticate(\Buzz\Message\Request $request)
    {
        $encoded = base64_encode($this->username . ':' . $this->password);
        $request->addHeader('Authorization: Basic ' . $encoded);
        
        return $request;
    }
}