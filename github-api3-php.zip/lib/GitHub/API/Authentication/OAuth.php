<?php

namespace GitHub\API\Authentication;
class OAuth implements AuthenticationInterface
{
    private $accessToken;
    public function __construct($accessToken)
    {
        $this->accessToken = $accessToken;
    }
    
    public function getToken()
    {
        return $this->accessToken;
    }
    
    public function setToken($accessToken)
    {
        $this->accessToken = $accessToken;
    }
    public function authenticate(\Buzz\Message\Request $request)
    {
        $url = $request->getUrl();
        $prefix = (strpos($url, '?') > 0) ? '&' : '?';
        
        $request->fromUrl($url . $prefix . 'access_token=' . $this->accessToken);
        
        return $request;
    }
}