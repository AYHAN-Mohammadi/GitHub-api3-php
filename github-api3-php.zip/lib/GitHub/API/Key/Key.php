<?php

namespace GitHub\API\Key;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
abstract class Key extends Api
{   
  
  protected function _all($url)
    {
        return $this->processResponse($this->requestGet($url));
    }

    protected function _get($url)
    {
        return $this->processResponse($this->requestGet($url));
    }

    protected function _create($url, $title, $key)
    {
        return $this->processResponse(
            $this->requestPost($url, array('title' => $title, 'key' => $key))
        );
    }

    protected function _update($url, $title = null, $key = null)
    {
        return $this->processResponse(
            $this->requestPatch($url, $this->buildParams(array('title' => $title, 'key' => $key)))
        );
    }

    protected function _delete($url)
    {
        return $this->processResponse($this->requestDelete($url));
    }
}
