<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Key extends \GitHub\API\Key\Key
{
    public function all($usename, $repo)
    {
        return $this->_all("repos/$username/$repo/keys");
    }
    public function get($usename, $repo, $id)
    {
        return $this->_get("repos/$username/$repo/keys/$id");
    }
    public function create($username, $repo, $title, $key)
    {
        return $this->_create("repos/$username/$repo/keys", $title, $key);
    }
    public function update($usename, $repo, $id, $title = null, $key = null)
    {
        return $this->_update("repos/$username/$repo/keys/$id", $title, $key);
    }
    public function delete($usename, $repo, $id)
    {
        return $this->_delete("repos/$username/$repo/keys/$id");
    }
}
