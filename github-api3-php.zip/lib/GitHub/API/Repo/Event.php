<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Event extends \GitHub\API\Event\Event
{
    public function all($usename, $repo, $issueId)
    {
        return $this->_all("repos/$username/$repo/issues/events");
    }

}
