<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Fork extends Api
{   public function all($username, $repo, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/forks", $this->buildPageParams($page, $pageSize))
        );;
    }
  
    protected function create($organization = null)
    {
        return $this->processResponse(
            $this->requestPost("repos/$username/$repo/forks", $this->buildParams(array('org' => $organization)))
        );
    }
}
