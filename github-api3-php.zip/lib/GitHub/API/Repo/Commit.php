<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Commit extends Api
{
    protected $comments   = null;
    public function all($username, $repo, $sha = null, $path = null)
    {
        $params = array(
           'sha'   => $sha,
           'path'  => $path
        );
        
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/commits", $this->buildParams($params))
        );
    }
    public function get($username, $repo, $sha)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/commits/$sha")
        );
    }
 
    public function comments()
    {
        if (null === $this->comments)
          $this->comments = new CommitComment($this->getTransport());
    
        return $this->comments;
    }
}
