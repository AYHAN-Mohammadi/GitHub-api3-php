<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Download extends Api
{
    public function all($username, $repo, $sha = null, $path = null)
    {
        $params = array(
            'sha'   => $sha,
            'path'  => $path
        );
      
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/downloads", $this->buildParams($params))
        );
    }
    public function get($username, $repo, $id)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/downloads/$id")
        );
    }
    public function create() {
        throw new ApiException("[create] not yet implemented");
    }
}
