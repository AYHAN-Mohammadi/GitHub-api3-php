<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
class Issue extends \GitHub\API\Issue\Issue
{   public function all($username, $repo, $filters = array(), $sort = array(), $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE, $format = self::FORMAT_RAW)
    {
        $params   = array_merge($filters, $sort, $this->buildPageParams($page, $pageSize));
    
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/issues", $params)
        );
    }
    public function get($username, $repo, $id, $format = self::FORMAT_RAW)
    {
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/milestones/$id", array(), $options)
        );
    }
    public function create($username, $repo, $title, $body = null, $assignee = null, $milestone = null, $labels = array(), $format = self::FORMAT_RAW)
    {
        $details = array_merge(
            array('title' => $title),
            $this->buildParams(array(
                'body'        => $body,
                'assignee'    => $assignee,
                'milestone'   => $milestone,
                'labels'      => $labels
            ))
        );
        
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestPost("repos/$username/$repo/issues", $details, $options)
        );
    }
    public function update($username, $repo, $id, $title, $body = null, $assignee = null, $milestone = null, $labels = array(), $state = self::STATE_OPEN, $format = self::FORMAT_RAW)
    {
        $details = array_merge(
            array('title' => $title),
            $this->buildParams(array(
                'body'        => $body,
                'assignee'    => $assignee,
                'milestone'   => $milestone,
                'labels'      => $labels,
                'state'       => $state
            ))
        );
    
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestPatch("repos/$username/$repo/issues/$id", $details, $options)
        );
    }

}
