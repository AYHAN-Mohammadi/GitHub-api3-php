<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
abstract class Repo extends Api
{
    const REPO_TYPE_ALL     = 'all';
    const REPO_TYPE_PUBLIC  = 'public';
    const REPO_TYPE_PRIVATE = 'private';
    const REPO_TYPE_MEMBER  = 'member';
    protected $allowedRepoTypes = array();
    protected $commit   = null;
    protected $collaborator   = null;
    protected $download   = null;
    protected $fork   = null;
    protected $key   = null;
    protected $event = null;
    public function get($username, $repo)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo")
        );
    }

    protected function _create($url, $repo, $details = array())
    {
        $details['name'] = $repo;
        
        return $this->processResponse(
            $this->requestPost($url, $this->buildParams($details))
        );
    }

    public function edit($username, $repo, $details = array())
    {
        $details['name'] = $repo;
        
        return $this->processResponse(
            $this->requestPatch("repos/$username/$repo", $this->buildParams($details))
        );
    }

    public function contributors($username, $repo, $includeAnonymous = true)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/contributors", array('anon' => $includeAnonymous))
        );
    }

    public function languages($username, $repo)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/languages")
        );
    }

    public function teams($username, $repo)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/teams")
        );
    }

    public function tags($username, $repo)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/tags")
        );
    }

    public function branches($username, $repo)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/branches")
        );
    }

    public function watchers($username, $repo, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/watchers", $this->buildPageParams($page, $pageSize))
        );
    }

    public function watched($username = null)
    {
        if (is_null($username))
            $url = 'user/watched';
        else
            $url = "users/$username/watched";

        return $this->processResponse(
            $this->requestGet($url)
        );
    }

    public function isWatched($username, $repo)
    {
        if (is_null($username))
            $url = 'user/watched';
        else
            $url = "users/$username/watched";

        return $this->processResponse(
            $this->requestGet($url)
        );
    }

    public function watch($username, $repo)
    {
        return $this->processResponse(
            $this->requestPut("user/watched/$username/$repo")
        );
    }

    public function unwatch($username, $repo)
    {
        return $this->processResponse(
            $this->requestDelete("user/watched/$username/$repo")
        );
    }

    public function commits()
    {
        if (null === $this->commit)
            $this->commit = new Commit($this->getTransport());

        return $this->commit;
    }

    public function collaborators()
    {
        if (null === $this->collaborator)
            $this->collaborator = new Collaborator($this->getTransport());

        return $this->collaborator;
    }

    public function downloads()
    {
        if (null === $this->download)
            $this->download = new Download($this->getTransport());

        return $this->download;
    }

    public function forks()
    {
        if (null === $this->fork)
            $this->fork = new Fork($this->getTransport());

        return $this->fork;
    }

    public function keys()
    {
        if (null === $this->key)
            $this->key = new Key($this->getTransport());

        return $this->key;
    }

    public function events()
    {
        if (null === $this->event)
            $this->event = new Event($this->getTransport());

        return $this->event;
    }

    public function stargazers($username, $repo, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/stargazers", $this->buildPageParams($page, $pageSize))
        );
    }

    public function starred($username = null)
    {
        if (is_null($username))
            $url = 'user/starred';
        else
            $url = "users/$username/starred";

        return $this->processResponse(
            $this->requestGet($url)
        );
    }

    public function isStarred($username, $repo)
    {
        $url = "users/starred/$username/$repo";

        return $this->processResponse(
            $this->requestGet($url)
        );
    }

    public function star($username, $repo)
    {
        return $this->processResponse(
            $this->requestPut("user/starred/$username/$repo")
        );
    }

    public function unstar($username, $repo)
    {
        return $this->processResponse(
            $this->requestDelete("user/starred/$username/$repo")
        );
    }
}
