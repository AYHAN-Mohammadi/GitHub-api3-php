<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Collaborator extends Api
{
    public function all($username, $repo)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/collaborators")
        );
    }
  
    public function isCollaborator($username, $repo, $checkUsername)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/collaborators/$checkUsername")
        );
    }

    public function create($username, $repo, $addUsername)
    {
        if (false === is_array($email))
          $email = array($email);
    
        return $this->processResponse(
            $this->requestPut("repos/$username/$repo/collaborators/$addUsername", $email)
        );
    }
  
    public function delete($username, $repo, $deleteUser)
    {
        return $this->processResponse(
            $this->requestDelete("repos/$username/$repo/collaborators/$deleteUser")
        );
    }
}
