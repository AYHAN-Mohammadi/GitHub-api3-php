<?php

namespace GitHub\API\Repo;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;


class CommitComment extends Api
{   
  const MIME_TYPE_RESOURCE = 'commitcomment';
  
    public function all($username, $repo, $sha = null, $format = self::FORMAT_RAW)
    {
        if (is_null($sha))
             $url = "repos/$username/$repo/comments";
        else
            $url = "repos/$username/$repo/commits/$sha/comments";
        
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestGet($url, array(), $options)
        );
    }
 
    public function get($username, $repo, $id, $format = self::FORMAT_RAW)
    {
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/comments/$id", array(), $options)
        );
    }
 
    public function create($username, $repo, $sha, $body, $line, $path, $position, $format = self::FORMAT_RAW)
    {
        $details = array(
            'body'      => $body,
            'commit_id' => $sha,
            'line'      => $line,
            'path'      => $path,
            'position'  => $position
        );
        
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestPost("repos/$username/$repo/commits/$sha/comments", $details, $options)
        );
    }
  
    public function update($username, $repo, $id, $body, $format = self::FORMAT_RAW)
    {
        $details = array('body' => $body);
        
        $options = $this->setResponseFormatOptions($format, self::MIME_TYPE_RESOURCE, array());
        
        return $this->processResponse(
            $this->requestPatch("repos/$username/$repo/comments/$id", $details, $options)
        );
    }
    public function delete($username, $repo, $id)
    {
        return $this->processResponse(
            $this->requestDelete("repos/$username/$repo/comments/$id")
        );
    }
}
