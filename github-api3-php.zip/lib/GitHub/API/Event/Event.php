<?php

namespace GitHub\API\Event;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
abstract class Key extends Api
{
    protected function _all($url)
    {
        return $this->processResponse(
            $this->requestGet($url)
        );
    }
    protected function get($username, $repo, $id)
    {
        return $this->processResponse(
            $this->requestGet("repos/$username/$repo/issues/events/$id")
        );
    }
}
