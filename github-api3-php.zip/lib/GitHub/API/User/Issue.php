<?php

namespace GitHub\API\User;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Issue extends \GitHub\API\Issue\Issue
{
    public function all($filters = array(), $sort = array(), $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE, $format = self::FORMAT_RAW)
    {
        $params   = array_merge($filters, $sort, $this->buildPageParams($page, $pageSize));

        return $this->processResponse(
            $this->requestGet("issues", $params)
        );
    }
}
