<?php

namespace GitHub\API\User;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;
use GitHub\API\Gist\Gist;

class User extends Api
{
    protected $email  = null;
    protected $key    = null;
    protected $repo   = null;
    protected $gist   = null;
    protected $issue   = null;

    public function get($username = null)
    {
        if (is_null($username))
            $url = 'user';
        else
            $url = "users/$username";

        return $this->processResponse($this->requestGet($url));
    }

    public function update(array $details)
    {
        return $this->processResponse($this->requestPatch('user', $details));
    }

    public function followers($username = null, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        if (is_null($username))
            $url = 'user/followers';
        else
            $url = "users/$username/followers";

        return $this->processResponse(
            $this->requestGet($url, $this->buildPageParams($page, $pageSize))
        );
    }

    public function following($username = null, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        if (is_null($username))
            $url = 'user/following';
        else
            $url = "users/$username/following";

        return $this->processResponse(
            $this->requestGet($url, $this->buildPageParams($page, $pageSize))
        );
    }

    public function isFollowing($username)
    {
        return $this->processResponse($this->requestGet("user/following/$username"));
    }

    public function follow($username)
    {
        return $this->processResponse($this->requestPut("user/following/$username"));
    }

    public function unfollow($username)
    {
        return $this->processResponse($this->requestDelete("user/following/$username"));
    }

    public function emails()
    {
        if (null === $this->email)
            $this->email = new Email($this->getTransport());

        return $this->email;
    }

    public function keys()
    {
        if (null === $this->key)
            $this->key = new Key($this->getTransport());

        return $this->key;
    }

    public function repos()
    {
        if (null === $this->repo)
            $this->repo = new Repo($this->getTransport());

        return $this->repo;
    }

    public function gists()
    {
        if (null === $this->gist)
            $this->gist = new Gist($this->getTransport());

        return $this->gist;
    }

    public function issues()
    {
        if (null === $this->issue)
            $this->issue = new Issue($this->getTransport());

        return $this->issue;
    }
}
