<?php

namespace GitHub\API\User;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Key extends \GitHub\API\Key\Key
{
    public function all()
    {
        return $this->_all('user/keys');
    }

    public function get($id)
    {
        return $this->_get("user/keys/$id");
    }

    public function create($title, $key)
    {
        return $this->_create('user/keys', $title, $key);
    }

    public function update($id, $title = null, $key = null)
    {
        return $this->_update("user/keys/$id", $title, $key);
    }

    public function delete($id)
    {
        return $this->_delete("user/keys/$id");
    }
}
