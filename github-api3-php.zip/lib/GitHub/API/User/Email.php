<?php

namespace GitHub\API\User;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Email extends Api
{
    public function all()
    {
        return $this->processResponse($this->requestGet('user/emails'));
    }

    public function create($email)
    {
        if (false === is_array($email))
            $email = array($email);

        return $this->processResponse($this->requestPost('user/emails', $email));
    }

    public function delete($email)
    {
        if (false === is_array($email))
            $email = array($email);

        return $this->processResponse($this->requestDelete('user/emails', $email));
    }
}
