<?php

namespace GitHub\API\User;

use GitHub\API\Api;
use GitHub\API\ApiException;
use GitHub\API\AuthenticationException;

class Repo extends \GitHub\API\Repo\Repo
{
    protected $allowedRepoTypes = array(
        self::REPO_TYPE_ALL, self::REPO_TYPE_PUBLIC, self::REPO_TYPE_PRIVATE, self::REPO_TYPE_MEMBER
    );

    public function all($username = null, $repoType = self::REPO_TYPE_ALL, $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        if (false === in_array($repoType, $this->allowedRepoTypes))
            throw new ApiException("Unsupported $repoType option. Available types are " . join(", ", $this->allowedRepoTypes));

        $params   = array_merge(array('type' => $repoType), $this->buildPageParams($page, $pageSize));

        if (is_null($username))
            $url = 'user/repos';
        else
        {
            if (self::REPO_TYPE_PUBLIC !== $repoType)
                throw new ApiException("Unsupported $repoType option. Unathenticated user requests can only list public repositories [ApiRepo::REPO_TYPE_PUBLIC]");

            $url = "users/$username/repos";
        }

        return $this->processResponse($this->requestGet($url, $params));
    }

    public function create($repo, $details = array())
    {
        return $this->_create('user/repos', $repo, $details);
    }
}
