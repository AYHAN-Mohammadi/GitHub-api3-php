<?php

namespace GitHub\API;
use Buzz\Browser;
class Api
{
    const API_URL            = 'https://api.github.com/';
    const FORMAT_JSON        = 'json';
    const FORMAT_RAW         = 'raw';
    const FORMAT_TEXT        = 'text';
    const FORMAT_HTML        = 'html';
    const FORMAT_FULL        = 'full';
    const HTTP_STATUS_OK                      = 200;
    const HTTP_STATUS_CREATED                 = 201;
    const HTTP_STATUS_NO_CONTENT              = 204;
    const HTTP_STATUS_BAD_REQUEST             = 400;
    const HTTP_STATUS_UNAUTHORIZED            = 401;
    const HTTP_STATUS_NOT_FOUND               = 404;
    const HTTP_STATUS_UNPROCESSABLE_ENTITY    = 422;
    const DEFAULT_PAGE_SIZE  = 30;
    
    protected $transport      = null;
    protected $authenticated = false;
    protected $authenticator  = null;

    public function __construct(Browser $transport = null)
    {
        if (null === $transport)
            $this->transport = new Browser();
        else
            $this->transport = $transport;
    }
    
    public function setCredentials(Authentication\AuthenticationInterface $authenticator)
    {
        $this->authenticator = $authenticator;
    }
    
    public function clearCredentials()
    {
        if (false === $this->isAuthenticated())
        {
            $this->authenticator = null;
        }
        else
            throw new ApiException('You must logout before clearing credentials. Use logout() first');
    }

    public function login()
    {
        if (null === $this->authenticator)
            throw new ApiException('Cannot login. You must specify the credentials first. Use setCredentials()');

        $this->authenticated = true;
    }

    public function logout($clearCredentials = false)
    {
        $this->authenticated = false;
        if (false === $clearCredentials)
            $this->clearCredentials();
    }

    public function isAuthenticated()
    {
        return $this->authenticated;
    }

    public function getTransport()
    {
        return $this->transport;
    }

    public function requestGet($url, $params = array(), $headers = array())
    {
        return $this->doRequest('GET', self::API_URL . $url, $params, $headers);
    }

    public function requestPost($url, $params = array(), $headers = array())
    {
        $params = (count($params)) ? json_encode($params) : null;

        return $this->doRequest('POST', self::API_URL . $url, $params, $headers);
    }

    public function requestPut($url, $params = array(), $headers = array())
    {
        $params = (count($params)) ? json_encode($params) : null;

        return $this->doRequest('PUT', self::API_URL . $url, $params, $headers);
    }

    public function requestPatch($url, $params = array(), $headers = array())
    {
        $params = (count($params)) ? json_encode($params) : null;

        return $this->doRequest('PATCH', self::API_URL . $url, $params, $headers);
    }

    public function requestDelete($url, $params = array(), $headers = array())
    {
        $params = (count($params)) ? json_encode($params) : null;

        return $this->doRequest('DELETE', self::API_URL . $url, $params, $headers);
    }


    protected function doRequest($method, $url, $params, $headers)
    {
        $request = $this->transport->createRequest();

        $request->setMethod($method);
        $request->fromUrl($url);
        $request->addHeaders($headers);
        $request->setContent($params);

        if ($this->isAuthenticated() && null !== $this->authenticator)
        {
            $request = $this->authenticator->authenticate($request);
        }
        
        return $this->transport->send($request);        
    }


    protected function buildPageParams($page, $pageSize) {
        return array(
            'page'      => $page,
            'per_page'  => $pageSize
        );
    }
    protected function buildParams($rawParams)
    {
        $params = array();

        foreach ($rawParams as $key=>$value)
        {
            if (false === is_null($value))
                $params[$key] = $value;
        }

        return $params;
    }

    
    protected function setResponseFormatOptions($format, $resourceKi, $options)
    {
        if (false === isset($options['headers']))
            $options['headers'] = array();

        $options['headers'][] = 'Accept: application/vnd.github-' . $resourceKi . '.' . $format . '+json';

        return $options;
    }

    
    protected function processResponse($response)
    {
        switch ($response->getStatusCode())
        {
            
            case self::HTTP_STATUS_OK:
            case self::HTTP_STATUS_CREATED:
                return $response->getContent();
                break;

            case self::HTTP_STATUS_NO_CONTENT:
                return true;
                break;

            case self::HTTP_STATUS_NOT_FOUND:
                return false;
                break;

            case self::HTTP_STATUS_BAD_REQUEST:
            case self::HTTP_STATUS_UNPROCESSABLE_ENTITY:
                return $response;
            case self::HTTP_STATUS_UNAUTHORIZED:
                throw new AuthenticationException("Unauthorized: Authentication required");
                break;

            default:
                return $response;
        }
    }
}

class ApiException extends \Exception {}
class AuthenticationException extends \Exception {}
