<?php

require_once dirname(__FILE__) . '/../lib/vendor/Symfony/Component/ClassLoader/UniversalClassLoader.php';

$loader = new Symfony\Component\ClassLoader\UniversalClassLoader();
$loader->registerNamespaces(array(
    'Buzz'              => __DIR__.'/../lib/vendor/Buzz/lib',
    'GitHub'            => __DIR__.'/../lib'
));
$loader->register();
use GitHub\API\Authentication;
use GitHub\API\User\User;
use GitHub\API\AuthenticationException;

$user = new User();
var_dump($user->get('Ayhan-Mohammadi'));
var_dump($user->following('Ayhan-Mohammadi'));
$user->setCredentials(new Authentication\Basic('username', 'password'));
$user->login();

try{
    var_dump($user->isFollowing("octocat"));
    var_dump($user->update(array('location' => 'Wales, United Kingdom')));
    var_dump($user->emails()->all());
    var_dump($user->keys()->create("New Key", "ssh-rsa CCC"));
}
catch (AuthenticationException $exception)
{
    echo $exception->getMessage();
}
$user->logout();